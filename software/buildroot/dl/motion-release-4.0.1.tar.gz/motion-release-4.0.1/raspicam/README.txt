The files in this directory are used in the MMAL/RaspberryPI camera
support code. The files were taken from the Raspberry PI userland git
repository:

https://github.com/raspberrypi/userland

The files are unchanged from the userland versions.

They are used to parse an options string and setup the camera
parameters appropriately. The format of the string is the same as
other raspberry pi camera tools.
