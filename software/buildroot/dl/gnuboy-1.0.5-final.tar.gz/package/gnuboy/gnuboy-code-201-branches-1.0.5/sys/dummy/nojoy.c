

#include "rc.h"

rcvar_t joy_exports[] =
{
	RCV_END
};

void joy_init()
{
}

void joy_close()
{
}

void joy_poll()
{
}


