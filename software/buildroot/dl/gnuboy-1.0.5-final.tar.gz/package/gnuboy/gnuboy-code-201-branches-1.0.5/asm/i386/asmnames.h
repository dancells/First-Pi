

#define cpu _cpu
#define hw _hw
#define ram _ram
#define mbc _mbc
#define lcd _lcd
#define scan _scan
#define patpix _patpix
#define anydirty _anydirty
#define patdirty _patdirty
#define cpu_emulate _cpu_emulate
#define cpu_step _cpu_step
#define lcdc_trans _lcdc_trans
#define debug_trace _debug_trace
#define updatepatpix _updatepatpix
#define debug_disassemble _debug_disassemble
#define bg_scan_color _bg_scan_color
#define refresh_1 _refresh_1
#define refresh_2 _refresh_2
#define refresh_3 _refresh_3
#define refresh_4 _refresh_4
#define refresh_1_2x _refresh_1_2x
#define refresh_2_2x _refresh_2_2x
#define refresh_3_2x _refresh_3_2x
#define refresh_4_2x _refresh_4_2x
#define refresh_1_3x _refresh_1_3x
#define refresh_2_3x _refresh_2_3x
#define refresh_3_3x _refresh_3_3x
#define refresh_4_3x _refresh_4_3x
#define refresh_1_4x _refresh_1_4x
#define refresh_2_4x _refresh_2_4x
#define refresh_3_4x _refresh_3_4x
#define refresh_4_4x _refresh_4_4x
#define mem_read _mem_read
#define mem_write _mem_write
#define cpu_idle _cpu_idle
#define die _die
#define printf _printf


