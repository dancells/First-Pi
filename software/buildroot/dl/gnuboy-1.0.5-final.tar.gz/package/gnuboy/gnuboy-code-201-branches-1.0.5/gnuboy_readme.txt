This project is an import of Laguna's gnuboy.
